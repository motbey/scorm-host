window.allowedOptions = () => ({
  outsideDriver: false
})
